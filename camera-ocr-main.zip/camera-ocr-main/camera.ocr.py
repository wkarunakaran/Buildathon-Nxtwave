import cv2
import pytesseract
import os
import pyttsx3
import time
from langdetect import detect

# Initialize text-to-speech engine
engine = pyttsx3.init()
engine.setProperty('rate', 150)

# Path to Tesseract executable
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'
os.environ['TESSDATA_PREFIX'] = r'C:\Program Files\Tesseract-OCR\tessdata'

# Supported languages (ISO 639-1 codes)
supported_languages = ['eng', 'tam', 'hin', 'kan', 'mal', 'tel', 'mar', 'ben']

# Text-to-speech helper with delay
last_spoken_time = 0
def speak(text):
    global last_spoken_time
    current_time = time.time()
    if current_time - last_spoken_time >= 7:
        print("Speaking:", text)
        engine.say(text)
        engine.runAndWait()
        last_spoken_time = current_time

# Detect blur
def is_blurry(frame):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    fm = cv2.Laplacian(gray, cv2.CV_64F).var()
    return fm < 100  # You can adjust this threshold

# OCR Function
def extract_text(img):
    text = pytesseract.image_to_string(img, lang='+'.join(supported_languages))
    return text.strip()

# Main camera loop
cap = cv2.VideoCapture(0)
speak("Camera started. Hold up the document in front of the camera.")
confirmed = False

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        speak("Failed to grab frame.")
        break

    cv2.imshow("Camera", frame)

    if is_blurry(frame):
        speak("The image is blurry. Please adjust your phone.")
    else:
        if not confirmed:
            speak("Image is clear. Can I convert this image to text?")
            confirmed = True
            time.sleep(5)
            # Simulating user confirmation
            speak("Converting the image to text now.")
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            text = extract_text(gray)
            if text:
                speak("Text found. Do you want me to read it for you?")
                time.sleep(5)
                # Simulating yes
                speak("Here is the content.")
                speak(text)
            else:
                speak("No readable text found in the image.")

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
