malayalam_braille_dict = {
    'ക': '⠅',
    'ഖ': '⠩',
    'ഗ': '⠛',
    'ഘ': '⠹',
    'ങ': '⠬',
    'ച': '⠉',
    'ഛ': '⠡',
    'ജ': '⠚',
    'ഝ': '⠯',
    'ഞ': '⠻',
    'ട': '⠾',
    'ഠ': '⠹',
    'ഡ': '⠙',
    'ഢ': '⠭',
    'ണ': '⠻',
    'ത': '⠞',
    'ഥ': '⠹',
    'ദ': '⠙',
    'ധ': '⠧',
    'ന': '⠝',
    'ഩ': '⠝⠝',
    'പ': '⠏',
    'ഫ': '⠋',
    'ബ': '⠃',
    'ഭ': '⠞',
    'മ': '⠍',
    'യ': '⠽',
    'ര': '⠗',
    'റ': '⠻',
    'ല': '⠇',
    'ള': '⠳',
    'ഴ': '⠮',
    'വ': '⠺',
    'ശ': '⠩',
    'ഷ': '⠯',
    'സ': '⠎',
    'ഹ': '⠓',
    'ഺ': '⠞⠞⠞',
    '൦': '⠚',
    '൧': '⠁',
    '൨': '⠃',
    '൩': '⠉',
    '൪': '⠙',
    '൫': '⠑',
    '൬': '⠋',
    '൭': '⠛',
    '൮': '⠓',
    '൯': '⠊',
    '.': '⠲',
    ',': '⠂',
    '।': '⠦',
    '॥': '⠖',
    'ഽ': '⠄',
    '൹': '⠼'
}

def malayalam_to_braille(malayalam_text):
    braille_output = ""
    for char in malayalam_text:
        if char in malayalam_braille_dict:
            braille_output += malayalam_braille_dict[char]
        else:
            braille_output += char  
    return braille_output
if __name__ == "__main__":
    malayalam_input = input("Enter Malayalam text to convert to Braille: ")
    braille_output = malayalam_to_braille(malayalam_input)
    print("Braille output: ", braille_output)
