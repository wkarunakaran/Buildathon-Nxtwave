


hindi_braille_dict = {
    'अ': '⠁',
    'आ': '⠅',
    'इ': '⠃',
    'ई': '⠊',
    'उ': '⠕',
    'ऊ': '⠎',
    'ऋ': '⠖',
    'ए': '⠋',
    'ऐ': '⠍',
    'ओ': '⠕',
    'औ': '⠕',
    'क': '⠉',
    'ख': '⠩',
    'ग': '⠛',
    'घ': '⠹',
    'ङ': '⠗',
    'च': '⠉',
    'छ': '⠘',
    'ज': '⠐',
    'झ': '⠖',
    'ञ': '⠝',
    'ट': '⠘',
    'ठ': '⠪',
    'ड': '⠐',
    'ढ': '⠘',
    'ण': '⠜',
    'त': '⠖',
    'थ': '⠝',
    'द': '⠘',
    'ध': '⠹',
    'न': '⠝',
    'प': '⠛',
    'फ': '⠋',
    'ब': '⠘',
    'भ': '⠩',
    'म': '⠝',
    'य': '⠽',
    'र': '⠉',
    'ल': '⠎',
    'व': '⠗',
    'श': '⠎',
    'ष': '⠖',
    'स': '⠘',
    'ह': '⠛',
    'क्ष': '⠛',
    'ज्ञ': '⠗'
}

def hindi_to_braille(hindi_text):
    braille_output = ""
    for char in hindi_text:
        if char in hindi_braille_dict:
            braille_output += hindi_braille_dict[char]
        else:
            braille_output += char  
    return braille_output

if __name__ == "__main__":
    hindi_input = input("Enter Hindi text to convert to Braille: ")
    braille_output = hindi_to_braille(hindi_input)
    print("Braille output: ", braille_output)
