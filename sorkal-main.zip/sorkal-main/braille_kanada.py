kannada_braille_dict = {
    'ಅ': '⠁',
    'ಆ': '⠜',
    'ಇ': '⠊',
    'ಈ': '⠔',
    'ಉ': '⠕',
    'ಊ': '⠾',
    'ಋ': '⠗',
    'ಎ': '⠑',
    'ಏ': '⠣',
    'ಐ': '⠜⠊',
    'ಒ': '⠕',
    'ಓ': '⠕⠜',
    'ಔ': '⠕⠕',
    'ಕ': '⠅',
    'ಖ': '⠩',
    'ಗ': '⠛',
    'ಘ': '⠹',
    'ಙ': '⠝',
    'ಚ': '⠉',
    'ಛ': '⠡',
    'ಜ': '⠚',
    'ಝ': '⠯',
    'ಞ': '⠻',
    'ಟ': '⠾',
    'ಠ': '⠞',
    'ಡ': '⠹',
    'ಢ': '⠽',
    'ಣ': '⠻',
    'ತ': '⠹',
    'ಥ': '⠹⠹',
    'ದ': '⠙',
    'ಧ': '⠹⠙',
    'ನ': '⠝',
    'ಪ': '⠏',
    'ಫ': '⠋',
    'ಬ': '⠃',
    'ಭ': '⠃⠃',
    'ಮ': '⠍',
    'ಯ': '⠽',
    'ರ': '⠗',
    'ಲ': '⠇',
    'ಳ': '⠭',
    'ವ': '⠺',
    'ಶ': '⠩',
    'ಷ': '⠯',
    'ಸ': '⠎',
    'ಹ': '⠓',
    'ಾ': '⠜',
    'ಿ': '⠊',
    'ೀ': '⠔',
    'ು': '⠕',
    'ೂ': '⠾',
    'ೃ': '⠗',
    'ೆ': '⠑',
    'ೇ': '⠣',
    'ೈ': '⠜⠊',
    'ೊ': '⠕',
    'ೋ': '⠕⠜',
    'ೌ': '⠕⠕',
    'ಂ': '⠴',
    'ಃ': '⠦',
    '್': ''  
}
def kannada_to_braille(kannada_text):
    braille_output = ""
    for char in kannada_text:
        if char in kannada_braille_dict:
            braille_output += kannada_braille_dict[char]
        else:
            braille_output += char  
    return braille_output
if __name__ == "__main__":
    kannada_input = input("Enter Kannada text to convert to Braille: ")
    braille_output = kannada_to_braille(kannada_input)
    print("Braille Output: ", braille_output)
