bengali_braille_dict = {
    'অ': '⠁',
    'আ': '⠜',
    'ই': '⠊',
    'ঈ': '⠔',
    'উ': '⠕',
    'ঊ': '⠾',
    'ঋ': '⠗',
    'এ': '⠑',
    'ঐ': '⠜⠊',
    'ও': '⠕',
    'ঔ': '⠕⠕',
    'ক': '⠅',
    'খ': '⠩',
    'গ': '⠛',
    'ঘ': '⠹',
    'ঙ': '⠝',
    'চ': '⠉',
    'ছ': '⠡',
    'জ': '⠚',
    'ঝ': '⠯',
    'ঞ': '⠻',
    'ট': '⠾',
    'ঠ': '⠞',
    'ড': '⠹',
    'ঢ': '⠽',
    'ণ': '⠻',
    'ত': '⠹',
    'থ': '⠹⠹',
    'দ': '⠙',
    'ধ': '⠹⠙',
    'ন': '⠝',
    'প': '⠏',
    'ফ': '⠋',
    'ব': '⠃',
    'ভ': '⠃⠃',
    'ম': '⠍',
    'য': '⠽',
    'র': '⠗',
    'ল': '⠇',
    'শ': '⠩',
    'ষ': '⠯',
    'স': '⠎',
    'হ': '⠓',
    'া': '⠜',
    'ি': '⠊',
    'ী': '⠔',
    'ু': '⠕',
    'ূ': '⠾',
    'ৃ': '⠗',
    'ে': '⠑',
    'ৈ': '⠜⠊',
    'ো': '⠕',
    'ৌ': '⠕⠕',
    'ং': '⠴',
    'ঃ': '⠦',
    '্': ''  
}

def bengali_to_braille(bengali_text):
    braille_output = ""
    for char in bengali_text:
        if char in bengali_braille_dict:
            braille_output += bengali_braille_dict[char]
        else:
            braille_output += char  
    return braille_output
# Main Execution
if __name__ == "__main__":
    bengali_input = input("Enter Bengali text to convert to Braille: ")
    braille_output = bengali_to_braille(bengali_input)
    print("Braille Output: ", braille_output)
