english_braille_dict = {
    'a': '⠁', 'b': '⠃', 'c': '⠉', 'd': '⠙', 'e': '⠑',
    'f': '⠋', 'g': '⠛', 'h': '⠓', 'i': '⠊', 'j': '⠚',
    'k': '⠅', 'l': '⠇', 'm': '⠍', 'n': '⠝', 'o': '⠕',
    'p': '⠏', 'q': '⠟', 'r': '⠗', 's': '⠎', 't': '⠞',
    'u': '⠥', 'v': '⠧', 'w': '⠺', 'x': '⠭', 'y': '⠽',
    'z': '⠵',
    '0': '⠼⠚', '1': '⠼⠁', '2': '⠼⠃', '3': '⠼⠉', '4': '⠼⠙',
    '5': '⠼⠑', '6': '⠼⠋', '7': '⠼⠛', '8': '⠼⠓', '9': '⠼⠊',
    '.': '⠲', ',': '⠂', '?': '⠦', '!': '⠖', '-': '⠤',
    ':': '⠒', ';': '⠆', '(': '⠶', ')': '⠶', '"': '⠦⠴',
    "'": '⠄', '/': '⠌', '@': '⠈⠁', '&': '⠈⠯', '*': '⠐⠔',
    '+': '⠖', '=': '⠶', '%': '⠨⠴', ' ': ' '
}

def english_to_braille(english_text):
    braille_output = ""
    for char in english_text.lower():  
        braille_output += english_braille_dict.get(char, char)  
    return braille_output

if __name__ == "__main__":
    english_input = input("Enter English text to convert to Braille: ")
    braille_output = english_to_braille(english_input)
    print("Braille Output: ", braille_output)
