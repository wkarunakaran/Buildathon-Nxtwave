marathi_braille_dict = {
    'अ': '⠁',
    'आ': '⠜',
    'इ': '⠊',
    'ई': '⠔',
    'उ': '⠕',
    'ऊ': '⠾',
    'ऋ': '⠗',
    'ए': '⠑',
    'ऐ': '⠜⠊',
    'ओ': '⠕',
    'औ': '⠕⠕',
    'क': '⠅',
    'ख': '⠩',
    'ग': '⠛',
    'घ': '⠹',
    'ङ': '⠝',
    'च': '⠉',
    'छ': '⠡',
    'ज': '⠚',
    'झ': '⠯',
    'ञ': '⠻',
    'ट': '⠾',
    'ठ': '⠞',
    'ड': '⠹',
    'ढ': '⠽',
    'ण': '⠻',
    'त': '⠹',
    'थ': '⠹⠹',
    'द': '⠙',
    'ध': '⠹⠙',
    'न': '⠝',
    'प': '⠏',
    'फ': '⠋',
    'ब': '⠃',
    'भ': '⠃⠃',
    'म': '⠍',
    'य': '⠽',
    'र': '⠗',
    'ल': '⠇',
    'ळ': '⠸',
    'व': '⠺',
    'श': '⠩',
    'ष': '⠯',
    'स': '⠎',
    'ह': '⠓',
    'ा': '⠜',
    'ि': '⠊',
    'ी': '⠔',
    'ु': '⠕',
    'ू': '⠾',
    'ृ': '⠗',
    'े': '⠑',
    'ै': '⠜⠊',
    'ो': '⠕',
    'ौ': '⠕⠕',
    'ं': '⠴',
    'ः': '⠦',
    '्': ''  
}
def marathi_to_braille(marathi_text):
    braille_output = ""
    for char in marathi_text:
        if char in marathi_braille_dict:
            braille_output += marathi_braille_dict[char]
        else:
            braille_output += char  
    return braille_output
if __name__ == "__main__":
    marathi_input = input("Enter Marathi text to convert to Braille: ")
    braille_output = marathi_to_braille(marathi_input)
    print("Braille Output: ", braille_output)
