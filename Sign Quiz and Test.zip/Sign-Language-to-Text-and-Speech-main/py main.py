import pickle
import cv2
import mediapipe as mp
import numpy as np
import pyttsx3
import tkinter as tk
from tkinter import StringVar, Label, Button, Frame, simpledialog
from PIL import Image, ImageTk
import threading
import time
import random
import warnings
import speech_recognition as sr
warnings.filterwarnings("ignore", category=UserWarning)

# Load Model
model_dict = pickle.load(open('./model.p', 'rb'))
model = model_dict['model']

# Mediapipe setup
mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils
mp_drawing_styles = mp.solutions.drawing_styles
hands = mp_hands.Hands(static_image_mode=False, min_detection_confidence=0.5, max_num_hands=1)

# TTS Engine
engine = pyttsx3.init()

def speak_text(text):
    def tts_thread():
        engine.say(text)
        engine.runAndWait()
    threading.Thread(target=tts_thread, daemon=True).start()

# Speech Recognition
recognizer = sr.Recognizer()
def recognize_speech():
    with sr.Microphone() as source:
        try:
            audio = recognizer.listen(source, timeout=5)
            response = recognizer.recognize_google(audio)
            return response.strip().lower()
        except:
            return ""

# Labels
labels_dict = {
    0: 'A', 1: 'B', 2: 'C', 3: 'D', 4: 'E', 5: 'F', 6: 'G', 7: 'H', 8: 'I', 9: 'J', 10: 'K', 11: 'L', 12: 'M',
    13: 'N', 14: 'O', 15: 'P', 16: 'Q', 17: 'R', 18: 'S', 19: 'T', 20: 'U', 21: 'V', 22: 'W', 23: 'X', 24: 'Y',
    25: 'Z', 26: '0', 27: '1', 28: '2', 29: '3', 30: '4', 31: '5', 32: '6', 33: '7', 34: '8', 35: '9',
    36: ' ', 37: '.'
}
expected_features = 42

# GUI Setup
root = tk.Tk()
root.title("Sign Language to Speech Conversion with Quiz")
root.geometry("1300x700")
root.configure(bg="#2c2f33")
root.resizable(False, False)

current_alphabet = StringVar(value="N/A")
current_word = StringVar(value="N/A")
current_sentence = StringVar(value="N/A")
quiz_timer_var = StringVar(value="")
is_paused = StringVar(value="False")

video_frame = Frame(root, bg="#2c2f33", bd=5, relief="solid", width=500, height=400)
video_frame.grid(row=1, column=0, rowspan=3, padx=20, pady=20)
video_frame.grid_propagate(False)

content_frame = Frame(root, bg="#2c2f33")
content_frame.grid(row=1, column=1, sticky="n", padx=(20, 40), pady=(60, 20))

button_frame = Frame(root, bg="#2c2f33")
button_frame.grid(row=3, column=1, pady=(10, 20), padx=(10, 20), sticky="n")

video_label = tk.Label(video_frame)
video_label.pack(expand=True)

Label(content_frame, text="Current Alphabet:", font=("Arial", 20), fg="#ffffff", bg="#2c2f33").pack(anchor="w", pady=(0, 10))
Label(content_frame, textvariable=current_alphabet, font=("Arial", 24, "bold"), fg="#1abc9c", bg="#2c2f33").pack(anchor="center")

Label(content_frame, text="Current Word:", font=("Arial", 20), fg="#ffffff", bg="#2c2f33").pack(anchor="w", pady=(20, 10))
Label(content_frame, textvariable=current_word, font=("Arial", 20), fg="#f39c12", bg="#2c2f33", wraplength=500).pack(anchor="center")

Label(content_frame, text="Current Sentence:", font=("Arial", 20), fg="#ffffff", bg="#2c2f33").pack(anchor="w", pady=(20, 10))
Label(content_frame, textvariable=current_sentence, font=("Arial", 20), fg="#9b59b6", bg="#2c2f33", wraplength=500).pack(anchor="center")

Label(content_frame, textvariable=quiz_timer_var, font=("Arial", 24), fg="#e67e22", bg="#2c2f33").pack(pady=20)

Button(button_frame, text="Reset", font=("Arial", 16), bg="#e74c3c", fg="#fff", command=lambda: reset_state(), height=2, width=14).grid(row=0, column=0, padx=10)
Button(button_frame, text="Pause", font=("Arial", 16), bg="#3498db", fg="#fff", command=lambda: toggle_pause(), height=2, width=14).grid(row=0, column=1, padx=10)
Button(button_frame, text="Speak Sentence", font=("Arial", 16), bg="#27ae60", fg="#fff", command=lambda: speak_text(current_sentence.get()), height=2, width=14).grid(row=0, column=2, padx=10)
Button(button_frame, text="Start Quiz", font=("Arial", 16), bg="#8e44ad", fg="#fff", command=lambda: start_quiz(), height=2, width=14).grid(row=1, column=0, columnspan=3, pady=10)

cap = cv2.VideoCapture(0)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 400)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 300)

# State Variables
stabilization_buffer = []
stable_char = None
word_buffer = ""
sentence = ""
last_registered_time = time.time()
registration_delay = 1.5
quiz_mode = False
quiz_questions = []
quiz_index = 0
quiz_total = 0
quiz_score = 0
quiz_timer = 15
current_quiz_char = ''
hold_symbol = False

# Helpers
def reset_state():
    global word_buffer, sentence, quiz_mode
    word_buffer = ""
    sentence = ""
    current_word.set("N/A")
    current_sentence.set("N/A")
    current_alphabet.set("N/A")
    quiz_timer_var.set("")
    quiz_mode = False

def toggle_pause():
    is_paused.set("False" if is_paused.get() == "True" else "True")

def start_quiz():
    global quiz_mode, quiz_questions, quiz_index, quiz_total, quiz_score, quiz_timer, current_quiz_char
    try:
        count = simpledialog.askinteger("Quiz Setup", "How many questions? (5/10/15)", minvalue=1, maxvalue=15)
        if count:
            quiz_questions = random.sample(list(labels_dict.values())[:26], count)
            quiz_index = 0
            quiz_score = 0
            quiz_total = count
            quiz_timer = 15
            current_quiz_char = quiz_questions[quiz_index]
            quiz_mode = True
            current_alphabet.set(f"Show: {current_quiz_char}")
            update_quiz_timer()
    except:
        pass

def update_quiz_timer():
    global quiz_timer, quiz_index, current_quiz_char, quiz_mode, quiz_score, hold_symbol
    if quiz_mode:
        quiz_timer_var.set(f"Time Left: {quiz_timer}s")
        if quiz_timer <= 0:
            quiz_index += 1
            quiz_timer = 15
            hold_symbol = False
            if quiz_index >= quiz_total:
                quiz_mode = False
                current_alphabet.set(f"Quiz Over: Score {quiz_score}/{quiz_total}")
                speak_text(f"Your score is {quiz_score} out of {quiz_total}")
                return
            else:
                current_quiz_char = quiz_questions[quiz_index]
                current_alphabet.set(f"Show: {current_quiz_char}")
        else:
            quiz_timer -= 1
            root.after(1000, update_quiz_timer)

def process_frame():
    global stabilization_buffer, stable_char, word_buffer, sentence, last_registered_time, quiz_index, quiz_score, quiz_timer, current_quiz_char, hold_symbol
    ret, frame = cap.read()
    if not ret:
        return

    if is_paused.get() == "True":
        show_frame(frame)
        root.after(10, process_frame)
        return

    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    results = hands.process(frame_rgb)

    if results.multi_hand_landmarks:
        for hand_landmarks in results.multi_hand_landmarks:
            data_aux = []
            x_ = [lm.x for lm in hand_landmarks.landmark]
            y_ = [lm.y for lm in hand_landmarks.landmark]

            for i in range(len(hand_landmarks.landmark)):
                data_aux.append(hand_landmarks.landmark[i].x - min(x_))
                data_aux.append(hand_landmarks.landmark[i].y - min(y_))

            if len(data_aux) < expected_features:
                data_aux.extend([0] * (expected_features - len(data_aux)))
            elif len(data_aux) > expected_features:
                data_aux = data_aux[:expected_features]

            prediction = model.predict([np.asarray(data_aux)])
            predicted_character = labels_dict[int(prediction[0])]

            if quiz_mode:
                if not hold_symbol and predicted_character == current_quiz_char:
                    hold_symbol = True
                    speak_text(f"Now say {current_quiz_char}")
                    def listen_answer():
                        global quiz_score, quiz_index, quiz_mode, current_quiz_char, quiz_timer, hold_symbol
                        answer = recognize_speech()
                        if answer == current_quiz_char.lower():
                            quiz_score += 1
                            speak_text("Correct")
                        else:
                            speak_text("Incorrect")
                        quiz_index += 1
                        quiz_timer = 15
                        hold_symbol = False
                        if quiz_index >= quiz_total:
                            quiz_mode = False
                            current_alphabet.set(f"Quiz Over: Score {quiz_score}/{quiz_total}")
                            speak_text(f"Your score is {quiz_score} out of {quiz_total}")
                        else:
                            current_quiz_char = quiz_questions[quiz_index]
                            current_alphabet.set(f"Show: {current_quiz_char}")
                    threading.Thread(target=listen_answer, daemon=True).start()
            else:
                stabilization_buffer.append(predicted_character)
                if len(stabilization_buffer) > 30:
                    stabilization_buffer.pop(0)

                if stabilization_buffer.count(predicted_character) > 25:
                    current_time = time.time()
                    if current_time - last_registered_time > registration_delay:
                        stable_char = predicted_character
                        last_registered_time = current_time
                        current_alphabet.set(stable_char)

                        if stable_char == ' ':
                            if word_buffer.strip():
                                speak_text(word_buffer)
                                sentence += word_buffer + " "
                                current_sentence.set(sentence.strip())
                            word_buffer = ""
                            current_word.set("N/A")
                        elif stable_char == '.':
                            if word_buffer.strip():
                                speak_text(word_buffer)
                                sentence += word_buffer + "."
                                current_sentence.set(sentence.strip())
                            word_buffer = ""
                            current_word.set("N/A")
                        else:
                            word_buffer += stable_char
                            current_word.set(word_buffer)

            mp_drawing.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS,
                                      mp_drawing_styles.get_default_hand_landmarks_style(),
                                      mp_drawing_styles.get_default_hand_connections_style())

    cv2.putText(frame, f"Alphabet: {current_alphabet.get()}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)
    show_frame(frame)
    root.after(10, process_frame)

def show_frame(frame):
    img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    img = Image.fromarray(img)
    img_tk = ImageTk.PhotoImage(image=img)
    video_label.imgtk = img_tk
    video_label.configure(image=img_tk)

process_frame()
root.mainloop()
