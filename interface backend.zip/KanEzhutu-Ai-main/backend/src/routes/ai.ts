import { Router } from 'express';
import { handleAiRequest } from '../services/openaiService';
import { ensureBrailleDomain } from '../middlewares/domainFilter';


const router = Router();


router.post('/respond', ensureBrailleDomain, async (req, res) => {
const { userId, prompt, progress } = req.body;
try {
const answer = await handleAiRequest({ userId, prompt, progress });
res.json(answer);
} catch (err) {
console.error(err);
res.status(500).json({ error: 'Internal error' });
}
});


export default router;