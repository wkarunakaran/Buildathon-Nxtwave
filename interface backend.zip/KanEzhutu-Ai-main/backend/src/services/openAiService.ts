// src/services/OpenAIService.ts

import OpenAI from "openai";

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY!,
});

// ---- SYSTEM PROMPT ---- //
const SYSTEM_PROMPT = `
You are Kanezhutu, a structured Braille tutor that teaches from beginner to advanced level.

LEARNING CURRICULUM (Sequential Order):
1. FOUNDATION (Lessons 1-3)
   - Touch and feel basics
   - Understanding the 6-dot cell structure
   - Finger positioning and reading technique

2. BASIC CHARACTERS (Lessons 4-10)
   - Letters A-J (dots 1,2,4,5)
   - Letters K-T (adding dot 3)
   - Letters U-Z (adding dots 3,6)
   - Numbers 1-0

3. WORDS & CONTRACTIONS (Lessons 11-15)
   - Simple 3-letter words
   - Common contractions (and, for, of, the, with)
   - Grade 1 vs Grade 2 Braille

4. SENTENCES & PUNCTUATION (Lessons 16-20)
   - Capital letters, periods, commas
   - Question marks, exclamation points
   - Simple sentence construction

5. ADVANCED GRAMMAR (Lessons 21-25)
   - Complex contractions
   - Abbreviations and symbols
   - Formatting rules

TEACHING BEHAVIOR:
- ALWAYS check user's current progress level first
- If no progress exists, start with Lesson 1
- Present ONE lesson at a time with clear objectives
- After each lesson, give practice exercises
- Wait for user completion before advancing
- Provide encouragement and corrections
- Never skip lessons or jump ahead without mastery

PROGRESS TRACKING:
- Always reference the user's current lesson number
- Track completed exercises and mastery level
- Provide lesson summaries and next steps
- Allow review of previous lessons if requested

MULTILINGUAL SUPPORT:
- ALWAYS respond in the SAME LANGUAGE the user communicates in
- Adapt all lessons to the user's language while maintaining Braille fundamentals
- Use culturally appropriate examples and context

Response format: Always start with "[Lesson X: Topic]" then provide the structured content.
`;

// ---- TYPE SAFE FUNCTION ---- //
export async function handleAiRequest({
  userId,
  prompt,
  progress,
}: {
  userId: string;
  prompt: string;
  progress?: any;
}) {
  // Build context with progress information
  let contextualPrompt = prompt;
  
  if (progress && progress.currentLesson) {
    contextualPrompt = `[STUDENT PROGRESS: Currently on Lesson ${progress.currentLesson}. Completed lessons: ${progress.completedLessons || 'None'}. Last activity: ${progress.lastActivity || 'Starting'}]

Student says: ${prompt}`;
  } else {
    contextualPrompt = `[NEW STUDENT: No previous progress. This is their first interaction.]

Student says: ${prompt}`;
  }

  // NEW OpenAI message format (2025)
  const messages: OpenAI.Chat.Completions.ChatCompletionMessageParam[] = [
    {
      role: "system",
      content: SYSTEM_PROMPT,
    },
    {
      role: "user",
      content: contextualPrompt,
    },
  ];

  // NEW API — correct call (chat.completions.create)
  const resp = await client.chat.completions.create({
    model: "gpt-4o-mini",
    messages,
    max_tokens: 400,
  });

  // Extract assistant response
  const text = resp.choices?.[0]?.message?.content ?? "";

  // Extract lesson number from response if present
  const lessonMatch = text.match(/\[Lesson (\d+):/i);
  const currentLesson = lessonMatch ? parseInt(lessonMatch[1]) : (progress?.currentLesson || 1);
  
  // Update progress
  const updatedProgress = {
    currentLesson,
    lastActivity: new Date().toISOString(),
    completedLessons: progress?.completedLessons || [],
    userId
  };

  return { 
    text, 
    progress: updatedProgress 
  };
}
