import { Request, Response, NextFunction } from 'express';


const ALLOWED_KEYWORDS = [
// English
'braille','dot','dots','cell','tactile','grade 1','grade 2','characters','cells','emboss','read','write','tactile alphabet',
// Tamil
'பிரெய்லி','புள்ளி','புள்ளிகள்','தொடு','படிக்க','எழுத',
// Hindi  
'ब्रेल','बिंदु','स्पर्श','पढ़ना','लिखना',
// Telugu
'బ్రెయిలీ','చుక్క','స్పర్శ','చదవడం','రాయడం',
// Kannada
'ಬ್ರೇಲ್','ಚುಕ್ಕೆ','ಸ್ಪರ್ಶ','ಓದು','ಬರೆ',
// Malayalam
'ബ്രെയിൽ','കുത്ത്','സ്പർശനം','വായിക്കുക','എഴുതുക',
// Bengali
'ব্রেইল','বিন্দু','স্পর্শ','পড়া','লেখা',
// Gujarati
'બ્રેઇલ','બિંદુ','સ્પર્શ','વાંચવું','લખવું',
// Marathi
'ब्रेल','बिंदू','स्पर्श','वाचणे','लिहिणे'
];


export function ensureBrailleDomain(req: Request, res: Response, next: NextFunction) {
const prompt: string = (req.body.prompt || '').toLowerCase();
if (!prompt) return res.status(400).json({ error: 'No prompt provided' });


// Quick keyword check — require at least one keyword present
const ok = ALLOWED_KEYWORDS.some(k => prompt.includes(k));
if (!ok) return res.status(400).json({ error: 'Please ask only Braille-related questions.' });
next();
}