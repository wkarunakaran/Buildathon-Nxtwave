import { useState, useEffect } from 'react'
import VoiceInput from './components/voiceInputs'
import VoiceOutput from './components/voiceOutputs'
import './App.css'

interface Progress {
  currentLesson: number;
  completedLessons: number[];
  lastActivity: string;
  userId: string;
}

interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

function App() {
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [inputText, setInputText] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [progress, setProgress] = useState<Progress | null>(null)
  const [userId] = useState(() => `user_${Date.now()}`)
  const [currentResponse, setCurrentResponse] = useState('')

  // Load progress from localStorage on mount
  useEffect(() => {
    const savedProgress = localStorage.getItem(`braille_progress_${userId}`)
    if (savedProgress) {
      setProgress(JSON.parse(savedProgress))
    }
  }, [userId])

  // Save progress to localStorage whenever it changes
  useEffect(() => {
    if (progress) {
      localStorage.setItem(`braille_progress_${userId}`, JSON.stringify(progress))
    }
  }, [progress, userId])

  const sendMessage = async (text: string) => {
    if (!text.trim()) return

    const userMessage: ChatMessage = {
      role: 'user',
      content: text,
      timestamp: new Date().toISOString()
    }

    setMessages(prev => [...prev, userMessage])
    setInputText('')
    setIsLoading(true)

    try {
      const response = await fetch('http://localhost:4000/api/ai/respond', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userId,
          prompt: text,
          progress
        })
      })

      const data = await response.json()

      if (response.ok) {
        const assistantMessage: ChatMessage = {
          role: 'assistant',
          content: data.text,
          timestamp: new Date().toISOString()
        }
        
        setMessages(prev => [...prev, assistantMessage])
        setCurrentResponse(data.text)
        
        // Update progress if provided
        if (data.progress) {
          setProgress(data.progress)
        }
      } else {
        throw new Error(data.error || 'Failed to get response')
      }
    } catch (error) {
      const errorMessage: ChatMessage = {
        role: 'assistant',
        content: `Error: ${error instanceof Error ? error.message : 'Something went wrong'}`,
        timestamp: new Date().toISOString()
      }
      setMessages(prev => [...prev, errorMessage])
    } finally {
      setIsLoading(false)
    }
  }

  const handleVoiceInput = (text: string) => {
    setInputText(text)
  }

  const handleAutoSubmit = (text: string) => {
    sendMessage(text)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    sendMessage(inputText)
  }

  return (
    <div className="app">
      <header className="app-header">
        <h1>🤚 Kanezhutu - Braille Learning Assistant</h1>
        {progress && (
          <div className="progress-info">
            <span>Lesson {progress.currentLesson} | Completed: {progress.completedLessons.length}</span>
          </div>
        )}
      </header>

      <main className="chat-container">
        <div className="messages">
          {messages.length === 0 && (
            <div className="welcome-message">
              <h2>Welcome to Braille Learning!</h2>
              <p>I'm Kanezhutu, your personal Braille tutor. I'll teach you Braille step by step, from basic touch techniques to advanced reading skills.</p>
              <p>Say "I want to learn braille" to get started!</p>
            </div>
          )}
          
          {messages.map((message, index) => (
            <div key={index} className={`message ${message.role}`}>
              <div className="message-content">
                {message.content}
              </div>
              <div className="message-time">
                {new Date(message.timestamp).toLocaleTimeString()}
              </div>
            </div>
          ))}
          
          {isLoading && (
            <div className="message assistant loading">
              <div className="message-content">Thinking...</div>
            </div>
          )}
        </div>

        <form onSubmit={handleSubmit} className="input-form">
          <div className="input-group">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Type your message or use voice input..."
              disabled={isLoading}
              className="text-input"
            />
            <VoiceInput 
              onResult={handleVoiceInput} 
              onAutoSubmit={handleAutoSubmit}
              isProcessing={isLoading}
            />
            <button type="submit" disabled={isLoading || !inputText.trim()} className="send-button">
              Send
            </button>
          </div>
        </form>
      </main>

      <VoiceOutput text={currentResponse} />
    </div>
  )
}

export default App
