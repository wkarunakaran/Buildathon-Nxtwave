interface HeroProps {
  onStartLearning: () => void;
}

export default function Hero({ onStartLearning }: HeroProps) {
  return (
    <section className="hero">
      <div className="container">
        <div className="hero-content">
          <div className="hero-text">
            <h1>Master Braille with AI-Powered Learning</h1>
            <p>
              Kanezhutu is your personal Braille tutor that teaches you step-by-step, 
              from basic touch techniques to advanced reading skills. Learn at your own pace 
              with multilingual support and voice interaction.
            </p>
            <div className="hero-buttons">
              <button className="btn-primary" onClick={onStartLearning}>
                🎓 Start Learning Now
              </button>
              <button className="btn-secondary">
                📖 View Demo
              </button>
            </div>
            <div className="hero-stats">
              <div className="stat">
                <span className="stat-number">25+</span>
                <span className="stat-label">Structured Lessons</span>
              </div>
              <div className="stat">
                <span className="stat-number">8+</span>
                <span className="stat-label">Languages Supported</span>
              </div>
              <div className="stat">
                <span className="stat-number">100%</span>
                <span className="stat-label">Free & Accessible</span>
              </div>
            </div>
          </div>
          <div className="hero-visual">
            <div className="braille-demo">
              <div className="braille-cell">
                <div className="dot active"></div>
                <div className="dot"></div>
                <div className="dot active"></div>
                <div className="dot active"></div>
                <div className="dot"></div>
                <div className="dot active"></div>
              </div>
              <p>Letter "K" in Braille</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}