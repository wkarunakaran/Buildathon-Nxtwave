import { useState, useEffect, useRef } from 'react';

interface VoiceInputProps {
  onResult: (text: string) => void;
  onAutoSubmit: (text: string) => void;
  isProcessing: boolean;
}

export default function VoiceInput({ onResult, onAutoSubmit, isProcessing }: VoiceInputProps) {
  const [isListening, setIsListening] = useState(false);
  const [isEnabled, setIsEnabled] = useState(false);
  const recognitionRef = useRef<any>(null);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);

  const startListening = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert('Speech recognition not supported in this browser');
      return;
    }

    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }

    const rec = new SpeechRecognition();
    rec.continuous = true;
    rec.interimResults = true;
    rec.lang = navigator.language || 'en-US';

    rec.onstart = () => setIsListening(true);
    
    rec.onresult = (e: any) => {
      let finalTranscript = '';
      
      for (let i = e.resultIndex; i < e.results.length; i++) {
        if (e.results[i].isFinal) {
          finalTranscript += e.results[i][0].transcript;
        }
      }
      
      if (finalTranscript.trim()) {
        onResult(finalTranscript.trim());
        
        // Clear existing timeout
        if (timeoutRef.current) {
          clearTimeout(timeoutRef.current);
        }
        
        // Auto-submit after 2 seconds of silence
        timeoutRef.current = setTimeout(() => {
          onAutoSubmit(finalTranscript.trim());
          rec.stop();
        }, 2000);
      }
    };
    
    rec.onend = () => {
      setIsListening(false);
      
      // Restart listening if enabled and not processing
      if (isEnabled && !isProcessing) {
        setTimeout(() => startListening(), 1000);
      }
    };
    
    rec.onerror = (e: any) => {
      console.error('Speech recognition error:', e.error);
      setIsListening(false);
    };

    recognitionRef.current = rec;
    rec.start();
  };

  const toggleVoiceMode = () => {
    if (isEnabled) {
      // Disable voice mode
      setIsEnabled(false);
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    } else {
      // Enable voice mode
      setIsEnabled(true);
      startListening();
    }
  };

  // Auto-restart listening after response is processed
  useEffect(() => {
    if (isEnabled && !isProcessing && !isListening) {
      const timer = setTimeout(() => {
        startListening();
      }, 1500); // Wait 1.5s after response before listening again
      
      return () => clearTimeout(timer);
    }
  }, [isProcessing, isEnabled, isListening]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, []);

  return (
    <button 
      onClick={toggleVoiceMode}
      aria-label={isEnabled ? "Stop voice mode" : "Start voice mode"}
      style={{ 
        background: isEnabled ? '#e53e3e' : '#48bb78',
        opacity: isProcessing ? 0.6 : 1 
      }}
      disabled={isProcessing}
    >
      {isEnabled ? (
        isListening ? '🎤 Listening...' : '⏸️ Voice On'
      ) : (
        '🎤 Voice Mode'
      )}
    </button>
  );
}