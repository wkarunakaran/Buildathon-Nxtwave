import React from 'react';

// Language detection based on text content
const detectLanguage = (text: string): string => {
  // Tamil Unicode range
  if (/[\u0B80-\u0BFF]/.test(text)) return 'ta-IN';
  // Hindi Unicode range
  if (/[\u0900-\u097F]/.test(text)) return 'hi-IN';
  // Telugu Unicode range
  if (/[\u0C00-\u0C7F]/.test(text)) return 'te-IN';
  // Kannada Unicode range
  if (/[\u0C80-\u0CFF]/.test(text)) return 'kn-IN';
  // Malayalam Unicode range
  if (/[\u0D00-\u0D7F]/.test(text)) return 'ml-IN';
  // Bengali Unicode range
  if (/[\u0980-\u09FF]/.test(text)) return 'bn-IN';
  // Gujarati Unicode range
  if (/[\u0A80-\u0AFF]/.test(text)) return 'gu-IN';
  
  // Default to English
  return 'en-US';
};

export default function VoiceOutput({ text }: { text: string }) {
  React.useEffect(() => {
    if (!text) return;
    
    // Cancel any ongoing speech
    window.speechSynthesis.cancel();
    
    const utterance = new SpeechSynthesisUtterance(text);
    
    // Detect language from text content
    utterance.lang = detectLanguage(text);
    utterance.rate = 0.7; // Slower for learning
    utterance.pitch = 1;
    utterance.volume = 1;
    
    console.log(`Speaking in language: ${utterance.lang}`);
    
    // Small delay to ensure previous speech is cancelled
    setTimeout(() => {
      window.speechSynthesis.speak(utterance);
    }, 100);
    
  }, [text]);
  
  return null;
}