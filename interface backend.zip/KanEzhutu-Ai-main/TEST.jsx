require("dotenv").config();
const { OpenAI } = require("openai"); // Use named import (if using a recent version of the OpenAI SDK)

// Initialize client with the API key
const client = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY
});

async function run() {
    try {
        const response = await client.chat.completions.create({
            model: "gpt-4.1-mini", // or use "gpt-3.5-turbo", depending on what's available
            messages: [
                { role: "user", content: "Write a one-sentence bedtime story about a unicorn." }
            ]
        });

        console.log(response.choices[0].message.content); // Print the result from the response
    } catch (error) {
        console.error("Error:", error);
    }
}

run();
